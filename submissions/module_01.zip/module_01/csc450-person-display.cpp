#include <iostream>
using namespace std;

int main(int argc, char **argv) {
	string firstName = "Taryn";
	string lastName = "Halberg";
	string streetAddress = "114 Spruce Haven Trail";
	string city = "Girdwood";
	string zip = "99587";

	// output the fictional persons name, address, city, state, and zip code
	cout << "First Name: " << firstName << endl;
	cout << "Last Name: " << lastName << endl;
	cout << "Street Address: " << streetAddress << endl;
	cout << "City: " << city << endl;
	cout << "Zip Code: " << zip << endl;
	
	return 0;
}
